# -*- coding: utf-8 -*-

from odoo import api, fields, models, tools, _

class PurchaseOrder(models.Model):
    _inherit = "purchase.order"
 
    sale_created = fields.Boolean(string='Sale Created',default=False)

    @api.multi
    def convert_to_so(self):
        for res in self:
            val = {}
            val['partner_id'] = res.partner_id.id
            val['date_order'] = res.date_order
            val['purchase_order_ref'] = res.id
            order_l = []
            for order_line in res.order_line:
                order_l.append([0,0,{'product_id':order_line.product_id.id,
                    'name':order_line.name,
                    'product_uom_qty':order_line.product_qty,
                    'price_unit':order_line.price_unit,
                    'product_uom':order_line.product_uom.id,
                    'tax_id':[(6, 0,order_line.taxes_id.ids)],
                    }])
            val['order_line'] = order_l
            self.env['sale.order'].create(val)
            res.sale_created = True

    @api.multi
    def open_to_so(self):
        for res in self:
            #sale_order = self.env['sale.order'].search([('purchase_order_ref','=',res.id)])
            sale_order = self.env['sale.order'].search([('id', '=', res.sale_order_reff.id)])
            return {
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'sale.order',
                'res_id': sale_order.ids[0],
                'view_id': False,
                'context': self.env.context,
                'type': 'ir.actions.act_window',
                'target': 'current',
            }
        
class SaleOrder(models.Model):
    _inherit = "sale.order"


    #purchase_order_ref = fields.Many2one("purchase.order",string="Purchase Order Ref")
    purchase_order_refs = fields.One2many("purchase.order","sale_order_reff",string="Purchase Order Ref")


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    sale_order_reff = fields.Many2one("sale.order",string="Sale Order Ref")

    @api.one
    def get_purchase_order(self):
        tab=[]
        ids = self.env['sale.order'].search([])
        for rec in ids:
         if self.id in rec.purchase_order_refs.ids  :
             tab.append(rec.id)
        self.sale_order_reff= tab[0] or False

