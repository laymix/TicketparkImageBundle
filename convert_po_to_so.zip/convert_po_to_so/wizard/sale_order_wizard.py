# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

import time
from odoo import api, fields, models, _
from datetime import datetime
import odoo.addons.decimal_precision as dp
from odoo.exceptions import UserError


class createsaleorder(models.TransientModel):
    _name = 'create.saleorder'
    _description = "Create Sale Order"

    new_order_line_ids = fields.One2many('getpurchase.orderdata', 'new_order_line_id', String="Order Line")
    partner_id = fields.Many2one('res.partner', string='Customer', required=True)
    date_order = fields.Datetime(string='Order Date', required=True, copy=False, default=fields.Datetime.now)
    purchase_order_ref = fields.Many2one('purchase.order',string="Purchase Order Ref")


    @api.model
    def default_get(self, default_fields):
        res = super(createsaleorder, self).default_get(default_fields)
        data = self.env['purchase.order'].browse(self._context.get('active_ids', []))
        update = []
        for record in data.order_line:
            update.append((0, 0, {
                'product_id': record.product_id.id,
                'product_uom': record.product_uom.id,
                #'order_id': record.order_id.id,
                'name': record.name,
                'product_uom_qty': record.product_uom_qty,
                'price_unit': record.price_unit,
                #'product_subtotal': record.price_subtotal,
                #'tax_id': [(6, 0, record.taxes_id.ids)],

            }))
        res.update({'new_order_line_ids': update,'purchase_order_ref': data.id})
        return res




    @api.multi
    def action_create_sale_order(self):
        self.ensure_one()
        res = self.env['sale.order'].browse(self._context.get('id', []))
        value = []
        #pricelist = self.partner_id.property_product_pricelist
        #partner_pricelist = self.partner_id.property_product_pricelist

        for data in self.new_order_line_ids:
        #    if partner_pricelist:
        #        product_context = dict(self.env.context, partner_id=self.partner_id.id, date=self.date_order,
        #                               uom=data.product_uom.id)
        #        final_price, rule_id = partner_pricelist.with_context(product_context).get_product_price_rule(
        #            data.product_id, data.product_qty or 1.0, self.partner_id)

        #    else:
            final_price = data.product_id.standard_price

            value.append([0, 0, {
                'product_id': data.product_id.id,
                'name': data.name,
                'product_uom_qty': data.product_uom_qty,
                #'order_id': data.order_id.id,
                'price_unit': data.price_unit,
                'product_uom': data.product_uom.id,
                #'tax_id': [(6, 0, data.taxes_id.ids)]
            }])
        res.create({
            'partner_id': self.partner_id.id,
            'date_order': str(self.date_order),
            'purchase_order_refs': [(6, 0, [(self.purchase_order_ref.id)])],
            'order_line': value,

        })

        tab1=self.env['purchase.order'].search([('id','=',self.purchase_order_ref.id)])
        if tab1:
            tab1[-1].write({'sale_created':True})
        return res


class Getsaleorderdata(models.TransientModel):
    _name = 'getpurchase.orderdata'
    _description = "Get Purchase Order Data"

    new_order_line_id = fields.Many2one('create.purchaseorder')
    product_id = fields.Many2one('product.product', string="Product", required=True)
    name = fields.Char(string="Description")
    product_uom_qty = fields.Float(string='Quantity', required=True)
    #date_planned = fields.Datetime(string='Scheduled Date', default=datetime.today())
    product_uom = fields.Many2one('product.uom', string='Product Unit of Measure')
    #order_id = fields.Many2one('purchase.order', string='Order Reference', required=True, ondelete='cascade', index=True,
    #                           copy=False)
    price_unit = fields.Float(string='Unit Price', required=True, digits=dp.get_precision('Product Price'))
    #product_subtotal = fields.Float(string="Sub Total", compute='_compute_total')

    #@api.depends('product_qty', 'price_unit')
    #def _compute_total(self):
    #    for record in self:
    #        record.product_subtotal = record.product_qty * record.price_unit
